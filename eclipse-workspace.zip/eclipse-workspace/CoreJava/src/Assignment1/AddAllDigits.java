package Assignment1;
import java.util.Scanner;
public class AddAllDigits {
	
	public static int addAllDigits(int num) {
		int rem;
		int ans=0;
		
		while(num>0) {
			rem=num%10;
			ans+=rem;
			num=num/10;
		}
		
		return ans;
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Input an integer between 0 and 1000:- ");
		int num=sc.nextInt();
		
		System.out.println(addAllDigits(num));
	}
}

