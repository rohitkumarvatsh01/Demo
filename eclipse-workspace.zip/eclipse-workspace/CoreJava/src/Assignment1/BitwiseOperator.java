package Assignment1;
import java.util.Scanner;
public class BitwiseOperator {
	
	public static int add(int a, int b) {
		while(b!=0) {
			int carry=a&b;
			a=a^b;
			b=carry<<1;
		}
		return a;
	}
	
	public static void main(String args[]) {
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter the Number1:- ");
		int num1=sc.nextInt();
		
		System.out.println("Enter the Number2:- ");
		int num2=sc.nextInt();
		
		System.out.println("Addition of Number1 and Number2 is:- "+add(num1,num2));
	}
}

