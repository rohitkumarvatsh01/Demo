package Assignment1;
import java.util.Scanner;

public class IncreasingDecreasingOrder {
	
	public static void increasingDecreasingOrder(int num1, int num2, int num3) {
		if(num1<num2 && num2<num3) {
			System.out.println("Increasing Order");
		}
		else if(num1>num2 && num2>num3) {
			System.out.println("Decreasing Order");
		}
		else {
			System.out.print("Neither Increasing or Descreasing Order");
		}
	}
	
	public static void main(String args[]) {
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Input First Number:- ");
		int num1=sc.nextInt();
		
		System.out.println("Input Second Number:- ");
		int num2=sc.nextInt();
		
		System.out.println("Input Third Number:- ");
		int num3=sc.nextInt();
		
		
		increasingDecreasingOrder(num1, num2, num3);
	}
}
