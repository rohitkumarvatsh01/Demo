package Assignment1;
public class TwinPrimeNumber {
	
	public static boolean isPrime(int n) {
		if(n<=1) {
			return false;
		}
		
		for(int i=2; i<=Math.sqrt(n); i++) {
			if(n%i==0) {
				return false;
			}
		}
		return true;
	}
	
	
	public static void twinsPrime(int num1, int num2) {
		for(int i=num1; i<num2; i++) {
			if(isPrime(i) && isPrime(i+2)) {
				System.out.println("("+i+","+(i+2)+")");
			}
		}
	}
	
	public static void main(String[] args) {
		
		int num1=1;
		int num2=100;
		
		twinsPrime(num1, num2);
	}
}

