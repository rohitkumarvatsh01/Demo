package Assignment2;
import java.util.Scanner;
public class FloatingPoint {
	
	public static void checkFloatingPoint(double num1, double num2) {
		
		num1=num1*1000;
		num1=num1/1000;
		
		num2=num2*1000;
		num2=num2/1000;
		
		if(num1==num2) {
			System.out.println("They are Same");
		}
		else {
			System.out.println("They are Different");
        }
	}
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Input first floating-point number: ");
		double num1=sc.nextDouble();
		
		System.out.println("Input second floating-point number: ");
		double num2=sc.nextDouble();
		
		checkFloatingPoint(num1, num2);
	}
}
