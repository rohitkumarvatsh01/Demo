package Assignment2;
import java.util.Scanner;
public class OddNaturalNumber {
	
	public static void sumOddNaturalNumber(int n) {
		int sum=0;
		for(int i=1;i<=n;i++){
			System.out.print(2*i-1+" ");
		    sum+=2*i-1;
		  }
		
		System.out.println("\nThe Sum of Odd Natural Number upto "+n+" tearms is: "+sum);
	}
	
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Input number of terms is: ");
		int n=sc.nextInt();
		
		sumOddNaturalNumber(n);
	}
}
