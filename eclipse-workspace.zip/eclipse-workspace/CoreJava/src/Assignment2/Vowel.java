package Assignment2;
import java.util.Scanner;
public class Vowel {
	
	public static String vowelCheck(String str) {
		
		for(int i=0; i<str.length(); i++) {
			char ch=str.charAt(i);
			
			if(ch=='A' || ch=='E' || ch=='I' || ch=='O' || ch=='U' ||
			   ch=='a' || ch=='e' || ch=='i' || ch=='o' || ch=='u')
			{
				return "Yes, string contains the vowel.";
			}
		}
		return "No, string not contains the vowel.";
	}
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter the String:- ");
		String str=sc.nextLine();
		
		System.out.println(vowelCheck(str));
	}
}
