package CollectionFramework;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DuplicateElementsMap {
	public static void main(String args[]) {
		
		List<Integer>list=new ArrayList<>();
		list.add(10);
		list.add(20);
		list.add(10);
		list.add(30);
		list.add(40);
		list.add(30);
		list.add(60);
		list.add(50);
		list.add(40);
		
		Map<Integer, Integer>map=new HashMap<>();
		
		for(int i:list) {
			if(map.containsKey(i)) {
				map.put(i,  map.get(i)+1);
			}
			else {
				map.put(i,  1);
			}
		}
		
		System.out.println("Duplicate Element:- ");
		for(Map.Entry<Integer, Integer> entry:map.entrySet()) {
			if(entry.getValue()>1) {
				System.out.println(entry.getKey());
			}
		}
		
	}
}
