package CollectionFramework;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

public class HashSetToList {
	public static void main(String args[]) {
		HashSet<Integer> set=new HashSet<>();
		
		set.add(1);
		set.add(3);
		set.add(4);
		set.add(6);
		set.add(7);
		
		System.out.println("The Element of HashSet is:- "+set);
		
		List<Integer> list=new ArrayList<>(set);
		System.out.println("Convert Into HashSet to List:- ");
		for(int ans:list) {
			System.out.println(ans);
		}
		
	}
}
