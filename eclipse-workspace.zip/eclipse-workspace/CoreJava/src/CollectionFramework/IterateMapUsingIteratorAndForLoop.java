package CollectionFramework;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class IterateMapUsingIteratorAndForLoop {
	public static void main(String args[]) {
		
		Map<Integer, String>map=new HashMap<>();
		map.put(1, "Rohit");
		map.put(2, "Rahul");
		map.put(3, "Mohan");
		map.put(4, "Rohan");
		map.put(5, "Ravi");
		
		System.out.println(map);
		
		System.out.println("Using Iterator:- ");
		Iterator<Integer> itr=map.keySet().iterator();
		while(itr.hasNext()) {
			int key=(int)itr.next();
			System.out.println("Roll: "+key+" Name: "+map.get(key));
		}
		
		System.out.println("*********************");
		
		System.out.println("Using For loop:- ");
		for (Map.Entry<Integer,String> entry : map.entrySet()) {
			System.out.println("Roll: "+entry.getKey()+" Name: "+entry.getValue());

		} 
	}
}
