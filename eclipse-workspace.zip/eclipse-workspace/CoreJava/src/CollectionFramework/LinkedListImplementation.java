package CollectionFramework;
import java.util.LinkedList;
import java.util.ListIterator;


public class LinkedListImplementation{
	public static void main(String args[]) {
		LinkedList<Integer> ans=new LinkedList<>();
		
		ans.add(1);
		ans.add(2);
		ans.add(3);
		ans.add(4);
		ans.add(5);
		
		System.out.println("Linked List Element are:- "+ans);
		
		int start=2;
		ListIterator<Integer> iterator1=ans.listIterator(start-1);
		
		System.out.println("The Linked List Started From Start"+start+" : ");
		while(iterator1.hasNext()) {
			System.out.println(iterator1.next());
		}
		
		ListIterator<Integer> iterator2=ans.listIterator(ans.size());
		
		System.out.println("The Linked List Started From End:- ");
		while(iterator2.hasPrevious()) {
			int current=iterator2.previousIndex();
			
			if(current>=start-1) {
				System.out.println(iterator2.previous());
			}
			else {
				iterator2.previous();
			}
		}
	}
}