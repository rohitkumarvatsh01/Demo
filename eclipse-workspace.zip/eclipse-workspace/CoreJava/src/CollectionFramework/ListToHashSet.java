package CollectionFramework;
import java.util.List;
import java.util.ArrayList;
import java.util.HashSet;

public class ListToHashSet {
	public static void main(String args[]) {
		
		List<String> str=new ArrayList<>();
		str.add("Rohit");
		str.add("Kumar");
		str.add("Singh");
		str.add("Rohit");
		
		System.out.println("ArrayList:- "+str);
		
		System.out.println("Convert into ArrayList to HashSet:- ");
		HashSet<String>ans=new HashSet<>(str);
		for(String s:ans) {
			System.out.println("HashSet:- "+ans);
		}
	}
}
