package CollectionFramework;

import java.util.HashMap;
import java.util.Map;

public class MapConatinsKeyValuePair {
	public static void main(String arg[]) {
		
		Map<Integer, String>map=new HashMap<>();
		map.put(1, "Java");
		map.put(2, "C++");
		map.put(3, "Oops");
		map.put(4, "Sql");
		map.put(5, "Database");
		
		System.out.println(map);
		
		boolean check=map.isEmpty();
		System.out.println("Map Contains key-value mappings or not:- "+check);
		
		map.clear();
		
		check=map.isEmpty();
		System.out.println("Map Contains key-value mappings or not:- "+check);
		
	}
}
