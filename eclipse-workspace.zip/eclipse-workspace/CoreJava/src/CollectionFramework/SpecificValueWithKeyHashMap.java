package CollectionFramework;

import java.util.HashMap;
import java.util.Scanner;

import java.util.Map;

public class SpecificValueWithKeyHashMap {
	public static void main(String args[]) {
		Map<Integer, String>map=new HashMap<>();
		
		map.put(1, "Rohit");
		map.put(2, "Rahul");
		map.put(3, "Rohan");
		map.put(4, "Ravi");
		
		System.out.println(map);
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Key in Form of Integer:- ");
		int key=sc.nextInt();
		
		System.out.println("Enter the Value of key "+key+" in Form of String:- ");
		String value=sc.next();
		sc.nextLine();
		
		map.put(key, value);
		
		System.out.println("Updated HashMap:- ");  
		   for(Map.Entry m : map.entrySet()){    
		    System.out.println(m.getKey()+" "+m.getValue());    
		} 
	}
}
