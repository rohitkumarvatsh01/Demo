package Constructor;

public class A {
	int rollNo;
	String name;
	
	A(){
		System.out.println(rollNo);
		System.out.println(name);
	}
	
	A(int a){
		this.rollNo=a;
		System.out.println(rollNo);
	}
	
	A(int a, String b){
		this.rollNo=a;
		this.name=b;
		System.out.println(rollNo);
		System.out.println(name);
	}
	
	public static void main(String[] args) {
		A obj1=new A();
		A obj2=new A(233);
		A obj3=new A(233, "Rohit");

	}
}
