package Constructor;
class B{
    
    int rollNo;
    String name;
    
    //Constructor
    B(){
        System.out.println("Roll No:- "+rollNo);
        System.out.println("Name:- "+name);
    }
    
    public static void main(String args[]){
        B obj=new B();
    }
}