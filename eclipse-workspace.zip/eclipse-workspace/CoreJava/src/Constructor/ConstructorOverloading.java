package Constructor;
public class ConstructorOverloading {
	
	int rollNo;
	String name;
	
	//Default Constructor
	ConstructorOverloading(){
		System.out.println("Roll No: "+rollNo);
		System.out.println("Nane: "+name);
	}
	
	//Parameterized Constructor With one Parameter.
	ConstructorOverloading(int a){
		this.rollNo=a;
		System.out.println("Roll No: "+rollNo);
	}

	//Parameterized Constructor With two Parameter
	ConstructorOverloading(int a, String b){
		this.rollNo=a;
		this.name=b;
		System.out.println("Roll No: "+rollNo);
		System.out.println("Nane: "+name);
	}
	
	public static void main(String args[]) {
		ConstructorOverloading obj=new ConstructorOverloading();
		ConstructorOverloading obj2=new ConstructorOverloading(233);
		ConstructorOverloading obj3=new ConstructorOverloading(233, "Rohit");
	}
}
