package Constructor;
public class DefaultConstructor {
	int a;
	String name;
	
	DefaultConstructor(){
		System.out.println("Default Constructor Called");
		System.out.println(a);
		System.out.println(name);
	}
	
	void show() {
		System.out.println("A:- "+a);
		System.out.println("Name:- "+name);
	}
	
	public static void main(String args[]) {
		DefaultConstructor obj=new DefaultConstructor();
		obj.show();
	}
}
