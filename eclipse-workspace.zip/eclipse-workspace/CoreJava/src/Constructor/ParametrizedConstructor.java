package Constructor;
public class ParametrizedConstructor {
	
	int rollNo;
	String name;
	
	ParametrizedConstructor(int a, String b){
		this.rollNo=a;
		this.name=b;
		
		System.out.println("Parametrized Constructor Called");
		System.out.println("Roll no:- "+rollNo);
		System.out.println("Name is:- "+name);
	}
	
	void display() {
		System.out.println("Roll no:- "+rollNo);
		System.out.println("Name is:- "+name);
	}
	
	public static void main(String[] args) {
		ParametrizedConstructor obj=new ParametrizedConstructor(233, "Rohit kumar");
		obj.display();
	}
}
