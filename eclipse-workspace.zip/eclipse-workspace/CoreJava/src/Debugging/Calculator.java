package Debugging;
import java.util.Scanner;

public class Calculator {
	
	//Add Method
	public static void add(int a, int b) {
		int ans=a+b;
		System.out.println("Addition of A and B is:- "+ans);
	}
	
	// Sub Method
	public static void sub(int a, int b) {
		int ans=a-b;
		System.out.println("Substraction of A and B is:- "+ans);
	}
	
	// Mul Method
	public static void mul(int a, int b) {
		int ans=a*b;
		System.out.println("Multipilication of A and B is:- "+ans);
	}
	
	// Div Method
	public static void div(int a, int b) {
		
		try {
			int ans=a/b;
			System.out.println("Division of A and B:- "+ans);
		}
		
		catch(ArithmeticException e) {
			System.out.println("Arithmetic Exception Occured, Can't Divide by Zero");
		}
		
		finally{
			System.out.println("Division Calculation Complete");
		}
	}
	
	/**
	 * @param args
	 */
	/**
	 * @param args
	 */
	public static void main(String args[]) {
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter the Number1:- ");
		int num1=sc.nextInt();
		
		System.out.println("Enter the Number2:- ");
		int num2=sc.nextInt();
		
		add(num1, num2);
		sub(num1, num2);
		mul(num1, num2);
		div(num1, num2);
	}
}
