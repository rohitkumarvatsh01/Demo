package Debugging;

public class DebugChallenge1 {
    public static void main(String[] args) {
        String input = "Hello, World!";
        String reversed = reverseString(input);
        System.out.println("Reversed String: " + reversed);
    }

    private static String reverseString(String input) {
        StringBuilder result = new StringBuilder();
        for (int i = input.length(); i >= 0; i--) {
            result.append(input.charAt(i));
        }
        return result.toString();
    }
}
