package Debugging;
public class DebugQuestion2 {
    public static void main(String[] args) {
        String text = "Debugging is fun!";
        String reversed = reverseText(text);
        System.out.println("Reversed Text: " + reversed);
    }
    private static String reverseText(String text) {
        StringBuilder result = new StringBuilder();
        for (int i = text.length()-1; i>=0; i--) {
            result.append(text.charAt(i));
        }
        return result.toString();
    }
}
