package Debugging;
import java.util.Scanner;
public class DebugQuestion3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a number: ");
        int num = scanner.nextInt();
        boolean isPrime = checkPrime(num);
        System.out.println("Is Prime? " + isPrime);
        scanner.close();
    }

    private static boolean checkPrime(int num) {
        if (num <= 1) {
            return false;
        }
        for (int i = 2; i <=num/2; i++) {
            if (num % i == 0) {
                return false;
            }
        }
        return true;
    }
}