package ExceptionHandling;

class InsufficientFundsException extends Exception {
    public InsufficientFundsException(String message) {
        super(message);
    }
}

class BankAccount {
    private double balance;

    public BankAccount() {
        balance = 0.0;
    }

    public void deposit(double amount) {
        balance += amount;
        System.out.println("Deposited: " + amount);
    }

    public void withdraw(double amount) throws InsufficientFundsException {
        if (amount > balance) {
        	 System.out.println("Withdrawn: " + amount);
            throw new InsufficientFundsException("Insufficient funds in the account.");
        }

        balance -= amount;
        System.out.println("Withdrawn: " + amount);
        System.out.println("Balance Left: " + balance); 
    }
  }

    class BankTransaction {
    public static void main(String[] args) {
        BankAccount account = new BankAccount();
        account.deposit(1000.0);
       
        try {
            account.withdraw(200.0);
            account.withdraw(150.0);
        } catch (InsufficientFundsException e) {
            System.out.println("Exception caught: " + e.getMessage());
        }
    }
}