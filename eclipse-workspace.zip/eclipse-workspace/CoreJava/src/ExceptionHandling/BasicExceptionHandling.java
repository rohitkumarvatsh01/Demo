package ExceptionHandling;
import java.util.Scanner;
public class BasicExceptionHandling {
	
	public static void exceptionHandling(int a, int b) {
		try {
			int ans=a/b;
			System.out.println("Result is: "+ans);
		}
		catch(ArithmeticException e) {
			System.out.println("Arithmetic Exception Occured. Division of Zero is not Allowed "+ e);
		}
	}

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter the Input1:- ");
		int a=sc.nextInt();
		
		System.out.println("Enter the Input2:- ");
		int b=sc.nextInt();
		
		exceptionHandling(a,b);
	}

}
