package ExceptionHandling;
import java.util.Scanner;

public class CalculatorExceptionHandling {
	
	//Calculator Method
	public static int calculator(int num1, int num2, char op) {
		int ans=0;
		
		//Switch Case
		switch(op) {
		
		case '+':
			ans=num1+num2;
			break;
		
		case '-':
			ans=num1-num2;
			break;
		
		case '*':
			ans=num1*num2;
			break;
			
		case '/':
			if(num2==0) {
				throw new ArithmeticException();
			}
			else {
				ans=num1/num2;
				break;
			}
		
		default:
			throw new IllegalArgumentException();
			
		}
		
		return ans;
	}
	
	//Main method
	public static void main(String args[]) {
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter the Number1:- ");
		int num1=sc.nextInt();
		
		System.out.println("Enter the Number2:- ");
		int num2=sc.nextInt();
		
		System.out.println("Enter the Operator:- ");
		char op=sc.next().charAt(0);
		
		// try-catch block
		try {
			int ans=calculator(num1, num2, op);
			System.out.println("Result of Number1 and Number2: "+ans);
		}
		catch(ArithmeticException e) {
			System.out.println("Disivion by Zero is not allowed. "+e);
		}
		catch(IllegalArgumentException e) {
			System.out.println("Invalid operator entered by user. "+e);
		}
	}
}
