package ExceptionHandling;
import java.util.Scanner;
public class CustomExceptions {
	
	public static void exceptionHandling(int num) {
		try {
			if (num<0) {
				throw new ArithmeticException(num+" Number is Negative Number");
			}    
            else {
                System.out.println(num + " is Positive Number");    	
            }
		}
		catch(ArithmeticException e){
			System.out.println("NegativeValueError: "+e);
		}
	}
	public static void main(String args[]) {
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter the Input:- ");
		int n=sc.nextInt();
		
		exceptionHandling(n);
	}
}
