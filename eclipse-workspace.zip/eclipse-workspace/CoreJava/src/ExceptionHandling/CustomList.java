package ExceptionHandling;
import java.util.*;

class ListSizeExceeds extends RuntimeException {
    public ListSizeExceeds(String message) {
        super(message);
    }
}

class CustomList {
    private static final int MAX_SIZE = 10;
    private List<Integer> list;

    public CustomList() {
        list = new ArrayList<>();
    }

    public void addElement(int element) {
        if (list.size() >= MAX_SIZE) {
            throw new ListSizeExceeds("List size exceeds the maximum limit.");
        }

        list.add(element);
        System.out.println("Added element: " + element);
    }

    public void removeElement(int index) {
        if (index < 0 || index >= list.size()) {
            throw new IndexOutOfBoundsException("Index out of bounds.");
        }

        int removedElement = list.remove(index);
        System.out.println("Removed element: " + removedElement);
    }
}

    class ListOperations {
    public static void main(String[] args) {
        CustomList customList = new CustomList();
        customList.addElement(10);
        customList.addElement(20);
        customList.addElement(30);

        try {
            for (int i = 0; i < 15; i++) {
                customList.addElement(i);
            }
        } catch (ListSizeExceeds e) {
            System.out.println("Exception caught: " + e.getMessage());
        }

        customList.removeElement(2);
        customList.removeElement(10); // This will throw IndexOutOfBoundsException
    }
}