package ExceptionHandling;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class FileHandlingException {
    public static void main(String[] args) {
        String fileName = "numbers.txt";
        calculateSumFromFile(fileName);
    }

    public static void calculateSumFromFile(String fileName) {
        BufferedReader reader = null;
        int sum = 0;

        try {
            reader = new BufferedReader(new FileReader(fileName));
            String line;

            while ((line = reader.readLine()) != null) {
                try {
                    int number = Integer.parseInt(line);
                    sum += number;
                } catch (NumberFormatException e) {
                    System.out.println("Error: Invalid number format in the file.");
                }
            }

            System.out.println("Sum of numbers: " + sum);
        } catch (FileNotFoundException e) {
            System.out.println("Error: File not found.");
        } catch (IOException e) {
            System.out.println("Error: An error occurred while reading the file.");
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    System.out.println("Error: An error occurred while closing the file.");
                }
            }
        }
    }
}