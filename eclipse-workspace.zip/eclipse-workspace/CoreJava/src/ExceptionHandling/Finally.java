package ExceptionHandling;
import java.util.Scanner;

public class Finally {
    public static void main(String[] args) {
    	 Scanner sc = new Scanner(System.in);
    	System.out.println("Enter first value: ");
        int dividend = sc.nextInt();
        System.out.println("Enter second value: ");
        int divisor = sc.nextInt();
        performDivision(dividend, divisor);
        sc.close();
    }

    public static void performDivision(int dividend, int divisor) {
        try {
            int result = dividend / divisor;
            System.out.println("Result of division: " + result);
        } catch (ArithmeticException e) {
            System.out.println("Error: Division by zero occurred.");
        } finally {
            System.out.println("Division operation complete.");
        }
    }
}