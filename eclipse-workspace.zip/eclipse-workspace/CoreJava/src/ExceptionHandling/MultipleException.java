package ExceptionHandling;
import java.util.ArrayList;
import java.util.List;

public class MultipleException {
    public static void main(String[] args) {
        List<Integer> numbers = new ArrayList<>();
        numbers.add(10);
        numbers.add(20);
        numbers.add(30);

        Operations(numbers);
    }

    public static void Operations(List<Integer> numbers) {
        try {
            // Divide each element by 2
            for (int i = 0; i < numbers.size(); i++) {
                int result = numbers.get(i) / 2;
                System.out.println("Result after division: " + result);
            }

            // Access an element at index 10
            int element = numbers.get(10);
            System.out.println("Element at index 10: " + element);
        } catch (ArithmeticException e) {
            System.out.println("Error: Division by zero occurred.");
        } catch (IndexOutOfBoundsException e) {
            System.out.println("Error: Index out of bounds.");
        }

        // Convert each element to a string
        for (int number : numbers) {
            try {
                String str = Integer.toString(number);
                System.out.println("Number as string: " + str);
            } catch (NumberFormatException e) {
                System.out.println("Error: Failed to convert number to string.");
            }
        }
    }
}