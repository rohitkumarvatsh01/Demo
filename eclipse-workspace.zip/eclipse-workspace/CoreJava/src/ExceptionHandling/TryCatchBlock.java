package ExceptionHandling;
import java.util.Scanner;

public class TryCatchBlock {
	
	public static void exception(int a, int b) {
		int ans;
		
		try {
			ans=a/b;
			System.out.println("Answer of Division:- "+ans);
		}
		catch(ArithmeticException e) {
			System.out.println("Arithmetic Exception is Occured "+ e);
		}
	}
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter the Value of a:- ");
		int a=sc.nextInt();
		
		System.out.println("Enter the Value of b:- ");
		int b=sc.nextInt();
		
		exception(a,b);
	}
}
