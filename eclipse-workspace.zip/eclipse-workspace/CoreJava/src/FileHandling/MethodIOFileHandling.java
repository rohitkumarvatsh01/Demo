package FileHandling;
import java.io.*;

public class MethodIOFileHandling {
    public static void main(String[] args) {

    	try {
            OutputStream outputStream = new FileOutputStream("output.txt");
            String byteData = "This is Byte Stream!";
            byte[] byteBytes = byteData.getBytes();
            outputStream.write(byteBytes);
            outputStream.close();
            
            System.out.println();

            InputStream inputStream = new FileInputStream("output.txt");
            int byteReadData;
            while ((byteReadData = inputStream.read()) != -1) {
                System.out.print((char) byteReadData);
            }
            inputStream.close();

        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            
            Writer writer = new FileWriter("char_output.txt");
            String charData = "This is Character Stream!";
            writer.write(charData);
            writer.close();
            
            System.out.println();

           
            Reader reader = new FileReader("char_output.txt");
            int charReadData;
            while ((charReadData = reader.read()) != -1) {
                System.out.print((char) charReadData);
            }
            reader.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

