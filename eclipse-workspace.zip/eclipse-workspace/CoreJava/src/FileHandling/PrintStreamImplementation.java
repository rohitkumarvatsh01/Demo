package FileHandling;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;

public class PrintStreamImplementation{
    public static void main(String[] args) {
       
        File outputFile = new File("output.txt");

        try {
          
            PrintStream obj = new PrintStream(outputFile);

            obj.println("PrintStream Program");
            obj.println("Rohit Kumar");
            obj.println(233);
            
            
            obj.printf("Formatted: %.2f%n", 1.2321);
            
            

            obj.close();
            ;
            System.out.println("Output File is Saved on this path " + outputFile.getAbsolutePath());
        } 
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
}