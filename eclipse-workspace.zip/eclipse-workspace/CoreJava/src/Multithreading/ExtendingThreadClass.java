package Multithreading;

class A extends Thread{
	public void run() {
		for(int i=0; i<=5; i++) {
			System.out.println("Class Method");
		}
	}
}

public class ExtendingThreadClass {
	public static void main(String args[]) throws InterruptedException{
		A obj=new A();
		
		obj.start();
		
		for(int i=0; i<=5; i++) {
			System.out.println("Main Method");
			obj.sleep(1000);
		}
	}
}
