package Multithreading;

class B implements Runnable{
	public void run() {
		for(int i=0; i<=5; i++) {
			System.out.println("Child Thread");
		}
	}
}

public class ImplementingRunnableInterface {
	public static void main(String args[]) throws InterruptedException {
		B obj1=new B();
		
		Thread obj2=new Thread(obj1);
		obj2.start();
		
		for(int i=0; i<=5; i++) {
			System.out.println("Main Method");
			obj2.sleep(1000);
		}
	}
}
