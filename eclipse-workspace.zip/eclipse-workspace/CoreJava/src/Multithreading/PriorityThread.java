package Multithreading;

class ThreadPriority1 extends Thread{
	public void run() {
		for(int i=0; i<=3; i++) {
			System.out.println("ThreadPriority1: "+i);
		}
	}
}

class ThreadPriority2  extends Thread{
	public void run() {
		for(int i=0; i<=5; i++) {
			System.out.println("ThreadPriority2: "+i);
		}
	}
}

public class PriorityThread {
	public static void main(String args[]) {
		Thread obj1=new Thread(new ThreadPriority1());
		Thread obj2=new Thread(new ThreadPriority2());
		
		obj1.setPriority(Thread.MAX_PRIORITY);
		obj2.setPriority(Thread.MIN_PRIORITY);
		
		obj1.run();
		obj2.run();

	}
}
