package Multithreading;
class Thread1 implements Runnable{
	public void run() {
		for(int i=1; i<=5; i++) {
			System.out.println("Thread1: "+i);
		}
	}
}

class Thread2 implements Runnable{
	public void run() {
		for(int i=1; i<=5; i++) {
			System.out.println("Thread2: "+i);
		}
	}
}

public class Question2 {
	public static void main(String args[]) throws InterruptedException {
		Thread obj1=new Thread(new Thread1());
		Thread obj2=new Thread(new Thread2());
		
		obj1.start();
		Thread.sleep(1000);
		obj2.run();
	
	}
}
