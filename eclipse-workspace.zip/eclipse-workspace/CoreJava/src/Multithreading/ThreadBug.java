package Multithreading;
class MyThread extends Thread {
    public void run() {
        for (int i = 0; i < 5; i++) {
            System.out.println(Thread.currentThread().getName() + " extends Thread - " + i);
            try {
                sleep(1000); 
                // Bug1: Calling sleep() method without Thread.sleep()
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
 
class MyRunnable implements Runnable {
    public void run() {
        for (int i = 0; i < 5; i++) {
            System.out.println(Thread.currentThread().getName() + " implements Runnable - " + i);
            try {
                Thread.sleep(1000); 
                // Bug2: Calling sleep() method with incorrect syntax
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
 
public class ThreadBug{
    public static void main(String[] args) {

    	MyThread thread1 = new MyThread();
        thread1.start();
        
        MyRunnable runnable = new MyRunnable();
        Thread thread2 = new Thread(runnable);
        thread2.start();
        thread2.run(); 
        // Bug: Calling run() directly instead of start() method
    }
}