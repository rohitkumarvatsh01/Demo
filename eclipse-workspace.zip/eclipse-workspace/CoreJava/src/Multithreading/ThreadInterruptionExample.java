package Multithreading;
public class ThreadInterruptionExample {
 
    public static class A implements Runnable {
        @Override
        public void run() {
            try {
                for (int i = 0; i < 10; i++) {
                    System.out.println("Task is running:- " + i);
                    Thread.sleep(1000);
                }
            } catch (InterruptedException e) {
                System.out.println("Task interrupted!");
            }
        }
    }
    
    public static void main(String[] args) {
        Thread obj = new Thread(new A());
        
        obj.start();
 
        try {
            Thread.sleep(3000); // Sleep for 3 seconds
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
 
        obj.interrupt();
    }
}