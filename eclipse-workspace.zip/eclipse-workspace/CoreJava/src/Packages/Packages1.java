package Packages;
import Constructor.*;
import Assignment1.*;
import Assignment2.*;
//import Assignment4.*; Inaccessable because this packages out side in directory.
public class Packages1 {
	
	int rollNo;
	String name;
	
	Packages1(int a, String b){
		this.rollNo=a;
		this.name=b;
	}
	
	void show() {
		System.out.println("Roll No:- "+rollNo);
		System.out.println("Name:- "+name);
	}
	
	public static void main(String args[]) {
		Packages1 obj=new Packages1(233, "Rohit Kumar");
		obj.show();
	}
}
