package Practice;

import java.util.Scanner;

class BankAccount {
    private int accountNumber;
    private String accountHolderName;
    private double balance;
 
    public BankAccount(int accountNumber, String accountHolderName) {
        this.accountNumber = accountNumber;
        this.accountHolderName = accountHolderName;
        this.balance = 0.0;
    }
 
    public int getAccountNumber() {
        return accountNumber;
    }
 
    public String getAccountHolderName() {
        return accountHolderName;
    }
 
    public double getBalance() {
        return balance;
    }
 
    public void deposit(double amount) {
        balance += amount;
        System.out.println("Amount deposited successfully.");
    }
 
    public void withdraw(double amount) {
        if (amount <= balance) {
            balance -= amount;
            System.out.println("Amount withdrawn successfully.");
        } else {
            System.out.println("Insufficient balance.");
        }
    }
}
 
public class Bank {
    private static final int MAX_ACCOUNTS = 50;
    private static BankAccount[] accounts = new BankAccount[MAX_ACCOUNTS];
    private static int numAccounts = 0;
private static Scanner scanner = new Scanner(System.in);
 
    public static void main(String[] args) {
        int choice;
        do {
            System.out.println("\n1. Open an Account");
            System.out.println("2. Deposit Amount");
            System.out.println("3. Withdraw Amount");
            System.out.println("4. Balance Enquiry");
            System.out.println("5. Close an Account");
            System.out.println("6. Display Details of all Accounts");
            System.out.println("7. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            switch (choice) {
                case 1:
                    openAccount();
                    break;
                case 2:
                    depositAmount();
                    break;
                case 3:
                    withdrawAmount();
                    break;
                case 4:
                    balanceEnquiry();
                    break;
                case 5:
                    closeAccount();
                    break;
                case 6:
                    displayAllAccounts();
                    break;
                case 7:
                    System.out.println("Exiting the program. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
                    break;
            }
        } while (choice != 7);
    }
 
    private static void openAccount() {
        if (numAccounts < MAX_ACCOUNTS) {
            System.out.print("Enter Account Number: ");
            int accNum = scanner.nextInt();
            scanner.nextLine(); // consume the newline character
            System.out.print("Enter Account Holder Name: ");
            String accHolderName = scanner.nextLine();
            accounts[numAccounts] = new BankAccount(accNum, accHolderName);
            numAccounts++;
            System.out.println("Account opened successfully.");
        } else {
            System.out.println("Maximum number of accounts reached.");
        }
    }
 
    private static void depositAmount() {
        System.out.print("Enter Account Number: ");
        int accNum = scanner.nextInt();
        System.out.print("Enter Deposit Amount: ");
        double amount = scanner.nextDouble();
        for (int i = 0; i < numAccounts; i++) {
            if (accounts[i].getAccountNumber() == accNum) {
                accounts[i].deposit(amount);
                return;
            }
        }
        System.out.println("Account not found.");
    }
 
    private static void withdrawAmount() {
        System.out.print("Enter Account Number: ");
        int accNum = scanner.nextInt();
        System.out.print("Enter Withdraw Amount: ");
        double amount = scanner.nextDouble();
        for (int i = 0; i < numAccounts; i++) {
            if (accounts[i].getAccountNumber() == accNum) {
                accounts[i].withdraw(amount);
                return;
            }
        }
        System.out.println("Account not found.");
    }
 
    private static void balanceEnquiry() {
        System.out.print("Enter Account Number: ");
        int accNum = scanner.nextInt();
        for (int i = 0; i < numAccounts; i++) {
            if (accounts[i].getAccountNumber() == accNum) {
                System.out.println("Balance for Account Number " + accNum + ": $" + accounts[i].getBalance());
                return;
            }
        }
        System.out.println("Account not found.");
    }
 
    private static void closeAccount() {
        System.out.print("Enter Account Number: ");
        int accNum = scanner.nextInt();
        for (int i = 0; i < numAccounts; i++) {
            if (accounts[i].getAccountNumber() == accNum) {
                // Remove the account by shifting elements
                for (int j = i; j < numAccounts - 1; j++) {
                    accounts[j] = accounts[j + 1];
                }
                numAccounts--;
                System.out.println("Account closed successfully.");
                return;
            }
        }
        System.out.println("Account not found.");
    }
 
    private static void displayAllAccounts() {
        if (numAccounts == 0) {
            System.out.println("No accounts found.");
            return;
        }
        System.out.println("Details of all Accounts:");
        for (int i = 0; i < numAccounts; i++) {
            System.out.println("Account Number: " + accounts[i].getAccountNumber());
            System.out.println("Account Holder Name: " + accounts[i].getAccountHolderName());
            System.out.println("Balance: " + accounts[i].getBalance());
            System.out.println("------------------------");
        }
    }
}
