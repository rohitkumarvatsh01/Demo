//Case 3:- Calling Method From Different Files
package Practice;

public class CallingMethodFromDifferentFiles {
	int a=10;
	
	void display() {
		System.out.println("Value of a:- "+a);
		System.out.println("Calling Method From Different Files");
	}
}
