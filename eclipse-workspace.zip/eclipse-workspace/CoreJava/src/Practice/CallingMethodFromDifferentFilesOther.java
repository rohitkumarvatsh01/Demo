//Case 3:- Calling Method From Different Files

package Practice;

public class CallingMethodFromDifferentFilesOther {
	public static void main(String[] args) {
		CallingMethodFromDifferentFiles obj=new CallingMethodFromDifferentFiles();
		obj.display();

	}
}
