package Practice;

class Parameter{
	int a=10;
	
	void show(int x) {
		System.out.println("Value of A:- "+a);
		System.out.println("Value of X:- "+x);
	}
}
public class CallingMethodFromParameterizedMethod {
	public static void main(String[] args) {
		Parameter obj=new Parameter();
		obj.show(100);
	}
}
