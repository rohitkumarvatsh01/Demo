//Case2:- Calling Method in Different Class
package Practice;

class Different{
	int a=10;
	
	void show() {
		System.out.println("Value of a:- "+a);
		System.out.println("Calling Method in Different Class");
	}
}

public class CallingMethodInDifferentClass {
	public static void main(String[] args) {
		Different obj=new Different();
		
		obj.show();
	}
}
