//Case 1: Calling Method in Same Class

package Practice;

public class CallingMethodInSameClass {
	
	int a=10;
	
	void show() {
		System.out.println("Value of a:- "+a);
		System.out.println("Calling Method in Same Class");
	}
	public static void main(String[] args) {
		CallingMethodInSameClass obj=new CallingMethodInSameClass();
		obj.show();
	}
}
