package Practice;

public class InfiniteLoop {
	public static void main(String[] args) {
		int count=0;
		
//		For Loop----------------------------
//		for(;;) {
//			System.out.println(count);
//			count++;
//		}

//   	While loop--------------------------
//		while(true) {
//			System.out.println(count);
//			count++;
//		}

//   	Do loop-----------------------------
		do {
			System.out.println(count);
			count++;
		}
		while(true);
	}
}
