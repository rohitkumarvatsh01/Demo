package Practice;

public class MainMethodOverloading {
	
	//Main Method-> Entry Point of Java Program.
	public static void main(String[] args) {
		System.out.println("Main Method");
	}
	
	public static void main(int[] args) {
		System.out.println("Overloaded Integer array Main Method");
	}
	
	public static void main(float[] args) {
		System.out.println("Overloaded Float array Main Mathod");
	}
	
	public static void main(char[] args) {
		System.out.println("Overloaded Character array Main Method");
	}
	
	 public static void main(double[] args){
	        System.out.println("Overloaded Double array Main Method");
	 }
}
