package Practice;
import java.util.Scanner;
public class MaximumElement {
	
	public static void maximumElement(int[] arr) {
		int max=Integer.MIN_VALUE;
		
		for(int i=0; i<arr.length; i++) {
			if(arr[i]>max) {
				max=arr[i];
			}
		}
		
		System.out.println("The Maximum Element in Array:- "+max);
	}
	
	public static void minimumElement(int[] arr) {
		int min=Integer.MAX_VALUE;
		
		for(int i=0; i<arr.length; i++) {
			if(arr[i]<min) {
				min=arr[i];
			}
		}
		
		System.out.println("The Minimum Element in Array:- "+min);
	}
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter the Size of Array:- ");
		int n=sc.nextInt();
		
		System.out.println("Enter the Element in Array:- ");
		int[] arr=new int[n];
		for(int i=0; i<n; i++) {
			arr[i]=sc.nextInt();
		}
		
		minimumElement(arr);
		maximumElement(arr);
	}
}
