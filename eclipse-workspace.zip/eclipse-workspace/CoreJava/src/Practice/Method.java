package Practice;
public class Method {
	
	//Method of add the two Number
	public static int addNum(int a, int b) {
		return a+b;
	}
	
	public static void main(String args[]) {
		int a=10;
		int b=20;
		
		int ans=addNum(a,b);
		System.out.println("Addition of two Number:- "+ans);	}
}
