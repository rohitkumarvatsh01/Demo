package Practice;

public class SingleClassMultipleObject {
	
	int a=10;
	
	void show() {
		System.out.println("Value of a is:- "+a);
	}
	
	public static void main(String[] args) {
		SingleClassMultipleObject obj1=new SingleClassMultipleObject();
		SingleClassMultipleObject obj2=new SingleClassMultipleObject();
		
		obj1.show();
		obj2.show();
	}
}
