package Practice;

public class VariableUsingObject {
	
	int a=10;
	
	void show() {
		System.out.println("Value of a Variable using object");
	}
	
	public static void main(String[] args) {
		VariableUsingObject obj=new VariableUsingObject();
		obj.show();
		
		System.out.println(obj.a);
	}
}
