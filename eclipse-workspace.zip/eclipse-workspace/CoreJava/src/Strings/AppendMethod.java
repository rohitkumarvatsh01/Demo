package Strings;
public class AppendMethod {
	
	public static void appendMethod(StringBuffer str1, StringBuffer str2) {
		
		str1.append(" "+str2);
		System.out.println(str1);
	}
	
	public static void main(String[] args) {
		
		StringBuffer str1=new StringBuffer("Rohit");
		StringBuffer str2=new StringBuffer("Kumar");
		
		appendMethod(str1, str2);
	}
}
