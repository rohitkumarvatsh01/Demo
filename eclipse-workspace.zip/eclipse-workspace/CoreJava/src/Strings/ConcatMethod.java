package Strings;

public class ConcatMethod {
	
	public static void concatMethod(String str1, String str2) {
		String str3=str1.concat(" "+str2);
		System.out.println("New String:- "+str3);
	}
	
	public static void main(String args[]) {
		
		String str1="Rohit";
		String str2="Kumar";
		
		concatMethod(str1, str2);
	}
}
