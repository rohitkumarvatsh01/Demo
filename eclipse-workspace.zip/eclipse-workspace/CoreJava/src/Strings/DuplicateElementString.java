package Strings;
import java.util.Scanner;

public class DuplicateElementString {
	
	public static void dupilcateElement(String str) {
		String duplicate="";
		
		for(int i=0; i<str.length()-1; i++) {
			for(int j=i+1; j<str.length(); j++) {
				if(str.charAt(i)==str.charAt(j)) {
					duplicate+=str.charAt(i);
				}
			}
		}
		
		System.out.println("String Duplicate:- "+duplicate);
	}
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter the String:- ");
		String str=sc.nextLine();
		
		dupilcateElement(str);
	}
}
