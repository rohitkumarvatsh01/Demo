package Strings;

public class EqualsMethod{
	
	public static boolean check(String str1, String str2) {
		if(str1.equals(str2)) {
			return true;
		}
		return false;
	}
	
	public static void main(String[] args) {
		
		String str1="Rohit";
		String str2=new String("Kumar");
		String str3=new String("Rohit");
		
		System.out.println(check(str1, str2));
		System.out.println(check(str1, str3));

	}
}
