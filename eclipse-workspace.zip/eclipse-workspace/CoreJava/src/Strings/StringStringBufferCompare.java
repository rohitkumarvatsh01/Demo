package Strings;

public class StringStringBufferCompare {
	public static void main(String[] args) {
		
		String str1="Rohit Kumar";
		StringBuffer str2=new StringBuffer("Rohit Kumar");
		
		boolean check=str1.equals(str2.toString());
		System.out.println("Content of String and StringBuffer:- "+check);
	}
}
