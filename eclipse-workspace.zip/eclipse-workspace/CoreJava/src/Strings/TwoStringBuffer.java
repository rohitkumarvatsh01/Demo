package Strings;

public class TwoStringBuffer {
	public static void main(String[] args) {
		
		StringBuffer str1=new StringBuffer("Rohit Kumar");
		StringBuffer str2=new StringBuffer("Rohit Kumar");
		
		boolean check = str1.toString().equals(str2.toString());
		System.out.println("Content of Two StringBuffer is Equal or Not:- "+check);
	}
}
