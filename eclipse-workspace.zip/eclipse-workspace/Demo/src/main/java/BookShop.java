import java.util.Scanner;

class BookShops {
	private String author;
	private String title;
	private double price;
	private String publisher;
	private int stockPosition;


	BookShops(String author, String title, double price, String pulisher, int stockPosition) {
		this.author=author;
		this.title=title;
		this.price=price;
		this.publisher=publisher;
		this.stockPosition=stockPosition;
	}

	public void searchBook(String inputTitle, String inputAuthor, int requiredCopies) {
		
		if(requiredCopies<=stockPosition) {
			double totalCost=price*requiredCopies;
			
			System.out.println("Book is Found in Stock");
			System.out.println("Title:- "+title);
			System.out.println("Author:- "+author);
			System.out.println("Publisher:- "+publisher);
			System.out.println("Price of book:- "+price);
			System.out.println("Number of Copy Availabe:- "+stockPosition);
		}
		else {
			System.out.println("Required Copies is not is Stock");
		}
	}
}



public class BookShop{
	public static void main(String[] args) {
		BookShops book=new BookShops("K&B", "Java", 500.00, "Head First Java", 30);
		
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter the Title of Book:- ");
		String inputTitle=sc.nextLine();
		
		System.out.println("Enter the Author of Book:- ");
		String inputAuthor=sc.nextLine();
		
		System.out.println("Enter the Required Copies:- ");
		int requiredCopies=sc.nextInt();
		
		
		book.searchBook(inputTitle, inputAuthor, requiredCopies);
		
	}
}
