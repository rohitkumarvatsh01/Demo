import java.util.Scanner;
public class GreatestThreeDigit {
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter the Value of a:- ");
		int a=sc.nextInt();
		
		System.out.println("Enter the Value of b:- ");
		int b=sc.nextInt();
		
		System.out.println("Enter the Value of b:- ");
		int c=sc.nextInt();
		
		if(a>c) {
			if(a>b) {
				System.out.println("a is Greater");
			}
			else {
				System.out.println("b is Greater");
			}
		}
		else {
			if(b>c) {
				System.out.println("b is Greater");
			}
			else {
				System.out.println("c is Greater");
			}
		}
	}
}
