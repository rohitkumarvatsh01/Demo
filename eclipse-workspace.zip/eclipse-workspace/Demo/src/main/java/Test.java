import java.util.Scanner;

class Bank{
	
    private String accountHolderName;
    private int accountNumber;
    private String accountType;
    private double balance;
    
    //Open Account
    public void openAccount(String name, int accNo, String accType, double initialBalance) {
        accountHolderName = name;
        accountNumber = accNo;
        accountType = accType;
        balance = initialBalance;
    }
    
    //Deposite in Account
    public void deposit(double amount) {
        balance += amount;
        System.out.println("Amount deposited successfully.");
    }
    
    //Withdraw in Account
    public void withdraw(double amount) {
        if (balance >= amount) {
            balance -= amount;
            System.out.println("Amount withdrawn successfully.");
        } else {
            System.out.println("Insufficient balance. Withdrawal failed.");
        }
    }

    public void displayAccountInfo() {
        System.out.println("Account Holder Name: " + accountHolderName);
        System.out.println("Account Number: " + accountNumber);
        System.out.println("Account Type: " + accountType);
        System.out.println("Balance: " + balance);
    }
}
public class Test{
    public static void main(String[] args) {
    	Bank obj = new Bank();
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter Account Holder Name:");
        String name = sc.nextLine();
        
        System.out.println("Enter Account Number:");
        int accNo = sc.nextInt();
        sc.nextLine();
        
        System.out.println("Enter Account Type:");
        String accType = sc.nextLine();
        
        System.out.println("Enter Initial Balance:");
        double initialBalance = sc.nextDouble();

        obj.openAccount(name, accNo, accType, initialBalance);
        obj.displayAccountInfo();

        System.out.println("Enter amount to deposit:");
        double depositAmount = sc.nextDouble();
        obj.deposit(depositAmount);
        obj.displayAccountInfo();

        System.out.println("Enter amount to withdraw:");
        double withdrawAmount = sc.nextDouble();
        obj.withdraw(withdrawAmount);
        obj.displayAccountInfo();
    }
    
}