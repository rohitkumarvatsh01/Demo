/**
 * 
 */

 function checkNumbers(num1, num2) {
  if (num1 === 100 || num2 === 100) {
    return true;
  }
  else if (num1 + num2 === 100) {
    return true;
  }else{
	return false;
	}
}

// Example usage:
console.log(checkNumbers(50, 50));   // true (sum is 100)
console.log(checkNumbers(100, 20));  // true (first number is 100)
console.log(checkNumbers(30, 70));   // true (sum is 100)
console.log(checkNumbers(40, 60));   // true (sum is 100)
console.log(checkNumbers(10, 20));   // false (sum is not 100)
console.log(checkNumbers(100, 100)); // false (both are 100, so sum is 200)
