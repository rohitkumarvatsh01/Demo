/**
 * 
 */

function countAndDisplayItems() {
  
  const dropdownList = document.getElementById("myDropdown");

  
  const numberOfItems = dropdownList.options.length;

  alert("Number of items in the dropdown list: " + numberOfItems);
}