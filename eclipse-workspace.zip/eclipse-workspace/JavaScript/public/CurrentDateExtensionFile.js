/**
 * 
 */

//a) To get Current date
function getCurrentDate() {
  
  const now = new Date();

  
  const formattedDate = now.toISOString().slice(0, 10);

  return formattedDate;
}

// Example:
const todaysDate = getCurrentDate();
console.log(todaysDate); // Output: 2023-12-25 (or the current date)



//b) To get the extension of any given filename.
function getFileExtension(filename) {
  
  const dotIndex = filename.lastIndexOf(".");

  
  if (dotIndex !== -1) {
    return filename.substring(dotIndex + 1);
  } else {
    return "";
  }
}

// Example usage:
const extension1 = getFileExtension("document.txt");   // Output: txt
const extension2 = getFileExtension("image.jpeg");    // Output: jpeg
const extension3 = getFileExtension("file_without_extension"); // Output: (empty string)
