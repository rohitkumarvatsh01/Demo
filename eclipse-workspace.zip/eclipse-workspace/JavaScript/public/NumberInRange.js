/**
 * 
 */

let number = prompt("Enter a number between 0 and 100:");

while (number < 0 || number > 100) {
  alert("Invalid number. Please enter a number between 0 and 100.");
  number = prompt("Enter a number between 0 and 100:");
}

console.log("You entered:", number);