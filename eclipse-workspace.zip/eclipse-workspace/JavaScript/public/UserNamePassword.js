document.addEventListener('DOMContentLoaded', function() {
  const form = document.getElementById('registrationForm');
  const usernameInput = document.getElementById('username');
  const passwordInput = document.getElementById('password');
  const confirmPasswordInput = document.getElementById('confirmPassword');
  const registerBtn = document.getElementById('registerBtn');
  const messageDiv = document.getElementById('message');
 
  function validateForm() {
    const username = usernameInput.value.trim();
    const password = passwordInput.value.trim();
    const confirmPassword = confirmPasswordInput.value.trim();
 
   
    const inputsFilled = username !== '' && password !== '' && confirmPassword !== '';
 
    
    const passwordsMatch = password === confirmPassword;
 
   
    registerBtn.disabled = !(inputsFilled && passwordsMatch);
  }
 
  form.addEventListener('submit', function(event) {
    event.preventDefault();
    const username = usernameInput.value.trim();
    messageDiv.textContent = `User "${username}" registered successfully!`;
    
  });
 
  
  usernameInput.addEventListener('input', validateForm);
  passwordInput.addEventListener('input', validateForm);
  confirmPasswordInput.addEventListener('input', validateForm);
  confirmPasswordInput.addEventListener('input', function() {
    const password = passwordInput.value.trim();
    const confirmPassword = confirmPasswordInput.value.trim();
 
    if (password !== confirmPassword) {
      confirmPasswordInput.setCustomValidity("Passwords don't match");
    } else {
      confirmPasswordInput.setCustomValidity('');
    }
  });
});