package Assignment1;
import java.util.Scanner;

public class Bank{
	
    private String accountHolderName;
    private int accountNumber;
    private String accountType;
    private double balance;

    public void openAccount(String name, int accNo, String accType, double initialBalance) {
        accountHolderName = name;
        accountNumber = accNo;
        accountType = accType;
        balance = initialBalance;
    }

    public void deposit(double amount) {
        balance += amount;
        System.out.println("Amount deposited successfully.");
    }

    public void withdraw(double amount) {
        if (balance >= amount) {
            balance -= amount;
            System.out.println("Amount withdrawn successfully.");
        } else {
            System.out.println("Insufficient balance. Withdrawal failed.");
        }
    }

    public void displayAccountInfo() {
        System.out.println("Account Holder Name: " + accountHolderName);
        System.out.println("Account Number: " + accountNumber);
        System.out.println("Account Type: " + accountType);
        System.out.println("Balance: " + balance);
    }

    public static void main(String[] args) {
    	Bank account = new Bank();
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter Account Holder Name:");
        String name = scanner.nextLine();
        
        System.out.println("Enter Account Number:");
        int accNo = scanner.nextInt();
        scanner.nextLine();
        
        System.out.println("Enter Account Type:");
        String accType = scanner.nextLine();
        
        System.out.println("Enter Initial Balance:");
        double initialBalance = scanner.nextDouble();

        account.openAccount(name, accNo, accType, initialBalance);
        account.displayAccountInfo();

        System.out.println("Enter amount to deposit:");
        double depositAmount = scanner.nextDouble();
        account.deposit(depositAmount);
        account.displayAccountInfo();

        System.out.println("Enter amount to withdraw:");
        double withdrawAmount = scanner.nextDouble();
        account.withdraw(withdrawAmount);
        account.displayAccountInfo();
    }
}