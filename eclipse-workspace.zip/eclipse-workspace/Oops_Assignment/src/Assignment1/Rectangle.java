package Assignment1;
public class Rectangle {
    private float length;
    private float width;

    public void setLength(float len) {
        length = len;
    }

    public void setWidth(float wid) {
        width = wid;
    }

    public float calculatePerimeter() {
        return 2 * (length + width);
    }

    public float calculateArea() {
        return length * width;
    }

    public void displayRectangleInfo() {
        System.out.println("Length: " + length);
        System.out.println("Width: " + width);
    }

    public int sameArea(Rectangle otherRectangle) {
        if (this.calculateArea() == otherRectangle.calculateArea()) {
            return 1;
        } else {
            return 0;
        }
    }

    public static void main(String[] args) {
        Rectangle rect1 = new Rectangle();
        Rectangle rect2 = new Rectangle();

        rect1.setLength(5);
        rect1.setWidth(2.5f);

        rect2.setLength(5);
        rect2.setWidth(18.9f);

        System.out.println("Rectangle 1:");
        rect1.displayRectangleInfo();
        System.out.println("Area: " + rect1.calculateArea());
        System.out.println("Perimeter: " + rect1.calculatePerimeter());

        System.out.println("\nRectangle 2:");
        rect2.displayRectangleInfo();
        System.out.println("Area: " + rect2.calculateArea());
        System.out.println("Perimeter: " + rect2.calculatePerimeter());

        if (rect1.sameArea(rect2) == 1) {
            System.out.println("\nThe two rectangles have the same area.");
        } else {
            System.out.println("\nThe two rectangles don't have the same area.");
        }

        rect1.setLength(15);
        rect1.setWidth(6.3f);

        System.out.println("\nUpdated Rectangle 1:");
        rect1.displayRectangleInfo();
        System.out.println("Area: " + rect1.calculateArea());
        System.out.println("Perimeter: " + rect1.calculatePerimeter());

        if (rect1.sameArea(rect2) == 1) {
            System.out.println("\nThe two rectangles have the same area.");
        } else {
            System.out.println("\nThe two rectangles don't have the same area.");
        }
    }
}

