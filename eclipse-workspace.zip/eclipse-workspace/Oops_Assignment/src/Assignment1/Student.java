package Assignment1;
import java.util.Scanner;

//Student Class
public class Student {
	 
	//Private Members of Student Class
	private int admno;
	private String sname;
	private float eng;
	private float math;
	private float science;
	private float total;
	
	//calTotal Function
	private void calTotal() {
		total=eng+math+science;
	}
	
	//Taking Data
	public void takeData(int admno, String sname, float eng, float math, float science) {
		this.admno=admno;
		this.sname=sname;
		this.eng=eng;
		this.math=math;
		this.science=science;
		calTotal();
	}
	
	//Showing
	public void showData() {
		System.out.println("The Admno is:- "+admno);
		System.out.println("The Sname of Student:- "+sname);
		System.out.println("The Marks of English:- "+eng);
		System.out.println("The Marks of Maths:- "+math);
		System.out.println("The Marks of Science:- "+science);
		
		System.out.println("Total Marks of All Subject:- "+total);
	}
	
	//Main Method
	public static void main(String args[]) {
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter the Admno:- ");
		int admno=sc.nextInt();
		
		System.out.println("Enter the Sname:- ");
		String sname=sc.nextLine();
		sname=sc.nextLine();
		
		System.out.println("Enter the Marks of English:- ");
		float eng=sc.nextFloat();;
		
		System.out.println("Enter the Marks of Maths:- ");
		float math=sc.nextFloat();
		
		System.out.println("Enter the Marks of Science:- ");
		float science=sc.nextFloat();
				
		Student obj=new Student();

		obj.takeData(admno, sname, eng, math, science);
		obj.showData();
	}
}

