package Assignment2;
import java.util.Scanner;

class Shape {
    protected double side1;
    protected double side2;
 
    public void getData() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter dimensions:");
        side1 = scanner.nextDouble();
        side2 = scanner.nextDouble();
        scanner.close();
    }
 
    public double calculateArea() {
        return 0.0; 
    }
 
    public void displayArea() {
        System.out.println("Area: " + calculateArea());
    }
}
 
class Triangle extends Shape {
    @Override
    public double calculateArea() {
        return 0.5 * side1 * side2; 
    }
}
 
class Rectangle extends Shape {
    @Override
    public double calculateArea() {
        return side1 * side2;
    }
}
 
class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter 1 for Triangle or 2 for Rectangle:");
        int choice = scanner.nextInt();
 
        Shape shape;
        if (choice == 1) {
            shape = new Triangle();
        } else if (choice == 2) {
            shape = new Rectangle();
        } else {
            System.out.println("Invalid choice.");
            scanner.close();
            return;
        }
 
        shape.getData();
        shape.displayArea();
    }
}