//package Assignment2;
//import java.util.Scanner;
//
//class Shape {
//    protected double side1;
//    protected double side2;
// 
//    public void getData() {
//        Scanner scanner = new Scanner(System.in);
//        System.out.println("Enter dimensions:");
//        side1 = scanner.nextDouble();
//        side2 = scanner.nextDouble();
//        scanner.close();
//    }
// 
//    public double calculateArea() {
//        return 0.0;
//    }
// 
//    public void displayArea() {
//        System.out.println("Area: " + calculateArea());
//    }
//}
// 
//class Triangle extends Shape {
//    @Override
//    public double calculateArea() {
//        return 0.5 * side1 * side2;
//    }
//}
// 
//class Rectangle extends Shape {
//    @Override
//    public double calculateArea() {
//        return side1 * side2;
//    }
//}
// 
//class Circle extends Shape {
//    @Override
//    public void getData() {
//        Scanner scanner = new Scanner(System.in);
//        System.out.println("Enter radius for circle:");
//        side1 = scanner.nextDouble();
//        side2 = 0.0;
//        scanner.close();
//    }
// 
//    @Override
//    public double calculateArea() {
//        return Math.PI * side1 * side1;
//    }
//}
// 
//public class Shapes {
//    public static void main(String[] args) {
//        Scanner scanner = new Scanner(System.in);
//        System.out.println("Enter 1 for Triangle, 2 for Rectangle, or 3 for Circle:");
//        int choice = scanner.nextInt();
// 
//        Shape shape;
//        if (choice == 1) {
//            shape = new Triangle();
//        } else if (choice == 2) {
//            shape = new Rectangle();
//        } else if (choice == 3) {
//            shape = new Circle();
//        } else {
//            System.out.println("Invalid choice.");
//            return;
//        }
// 
//        shape.getData();
//        shape.displayArea();
//    }
//}
