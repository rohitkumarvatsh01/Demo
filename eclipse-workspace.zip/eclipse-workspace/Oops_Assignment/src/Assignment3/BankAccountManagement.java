package Assignment3;

import java.util.Scanner;

class Account {
    protected String customerName;
    protected int accountNumber;
    protected String accountType;
    protected double balance;
 
    public void acceptDetails() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter customer name: ");
        customerName = scanner.nextLine();
        
        System.out.print("Enter account number: ");
        accountNumber = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        
        System.out.print("Enter account type (Savings/Current): ");
        accountType = scanner.nextLine();
        
        System.out.print("Enter initial balance: ");
        balance = scanner.nextDouble();
    }
    
    // A) Accept the deposite and Update the balance 
    public void deposit(double amount) {
        balance += amount;
        System.out.println("Deposit successful. Updated balance: " + balance);
    }
 
    //B) Display the Balance
    public void displayBalance() {
        System.out.println("Current Balance: " + balance);
    }
}

// Class Current Account
class Cur_Acct extends Account {
    private final double minimumBalance = 1000;
    private final double serviceCharge = 50;
 

    public void deposit(double amount) {
        super.deposit(amount);
        checkMinimumBalance();
    }
 
    public void checkMinimumBalance() {
        if (balance < minimumBalance) {
            balance -= serviceCharge;
            System.out.println("Minimum balance not maintained. Service charge imposed: " + serviceCharge);
        }
    }
 
    public void withdraw(double amount) {
        if (balance >= amount) {
            balance -= amount;
            System.out.println("Withdrawal successful. Updated balance: " + balance);
            checkMinimumBalance();
        } else {
            System.out.println("Insufficient balance.");
        }
    }
}

// Class Saving Account
class Sav_Acct extends Account {
    private final double interestRate = 0.05;
 
    public void computeInterest() {
        double interest = balance * interestRate;
        balance += interest;
        System.out.println("Interest computed and added: " + interest);
    }
 
    public void withdraw(double amount) {
        if (balance >= amount) {
            balance -= amount;
            System.out.println("Withdrawal successful. Updated balance: " + balance);
        } else {
            System.out.println("Insufficient balance.");
        }
    }
}
 
public class BankAccountManagement {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
 
        System.out.println("Creating a Current Account:");
        Cur_Acct currentAccount = new Cur_Acct();
        currentAccount.acceptDetails();
 
        System.out.println("\nCreating a Savings Account:");
        Sav_Acct savingsAccount = new Sav_Acct();
        savingsAccount.acceptDetails();
 
        System.out.print("\nEnter deposit amount for Current Account: ");
        double curDeposit = scanner.nextDouble();
        currentAccount.deposit(curDeposit);
 
        System.out.print("\nEnter withdrawal amount for Current Account: ");
        double curWithdraw = scanner.nextDouble();
        currentAccount.withdraw(curWithdraw);
 
        System.out.print("\nEnter interest computation amount for Savings Account: ");
        double savAmount = scanner.nextDouble();
        savingsAccount.deposit(savAmount);
        savingsAccount.computeInterest();
 
    }
}