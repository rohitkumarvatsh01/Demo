package Assignment3;
import java.util.ArrayList;
import java.util.Scanner;

class Employee {
    protected int staffCode;
    protected String name;

    public void setData(int staffCode, String name) {
        this.staffCode = staffCode;
        this.name = name;
    }

    public void displayInfo() {
        System.out.println("Staff Code: " + staffCode);
        System.out.println("Name: " + name);
    }
}

class Teacher extends Employee {
    private String subject;
    private String publication;

    public void setData(int staffCode, String name, String subject, String publication) {
        super.setData(staffCode, name);
        this.subject = subject;
        this.publication = publication;
    }

    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.println("Subject: " + subject);
        System.out.println("Publication: " + publication);
    }
}

class Officer extends Employee {
    private String grade;

    public void setData(int staffCode, String name, String grade) {
        super.setData(staffCode, name);
        this.grade = grade;
    }

    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.println("Grade: " + grade);
    }
}

class Typist extends Employee {
    private int speed;

    public void setData(int staffCode, String name, int speed) {
        super.setData(staffCode, name);
        this.speed = speed;
    }

    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.println("Speed: " + speed + " wpm");
    }
}

class Regular extends Typist {
}

class Casual extends Typist {
    private double dailyWages;

    public void setData(int staffCode, String name, int speed, double dailyWages) {
        super.setData(staffCode, name, speed);
        this.dailyWages = dailyWages;
    }

    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.println("Daily Wages: $" + dailyWages);
    }
}

class EmployeeDatabase {
    private ArrayList<Employee> employees = new ArrayList<>();

    public void addEmployee(Employee employee) {
        employees.add(employee);
    }

    public void displayAllEmployees() {
        for (Employee employee : employees) {
            employee.displayInfo();
            System.out.println();
        }
    }
}

public class EducationalInstitution {
    public static void main(String[] args) {
        EmployeeDatabase database = new EmployeeDatabase();
        Scanner scanner = new Scanner(System.in);

        Teacher teacher = new Teacher();
        teacher.setData(233, "Manisha Jha", ".net", ".Net");
        database.addEmployee(teacher);

        Officer officer = new Officer();
        officer.setData(234, "John", ".net");
        database.addEmployee(officer);

        Casual casualTypist = new Casual();
        casualTypist.setData(301, "Vanshika", 65, 80.0);
        database.addEmployee(casualTypist);

        database.displayAllEmployees();
    }
}
