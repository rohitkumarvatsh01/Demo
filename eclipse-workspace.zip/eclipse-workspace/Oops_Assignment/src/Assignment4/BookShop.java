package Assignment4;
import java.util.Scanner;

class Book {
    private String title;
    private String author;
    private double price;
    private String publisher;
    private int stockPosition;

    public Book(String title, String author, double price, String publisher, int stockPosition) {
        this.title = title;
        this.author = author;
        this.price = price;
        this.publisher = publisher;
        this.stockPosition = stockPosition;
    }

    public void checkAvailability(String inputTitle, String inputAuthor) {
        if (title.equalsIgnoreCase(inputTitle) && author.equalsIgnoreCase(inputAuthor)) {
            System.out.println("Book is found!");
            displayBookDetails();
        } else {
            System.out.println("Book is not available.");
        }
    }

    private void displayBookDetails() {
        System.out.println("Title:- " + title);
        System.out.println("Author:- " + author);
        System.out.println("Price:- " + price);
        System.out.println("Publisher:- " + publisher);
        System.out.println("Stock Position:- " + stockPosition + " copies");
    }

    public void processBookRequest(int requiredCopies) {
        if (requiredCopies <= stockPosition) {
            double totalCost = requiredCopies * price;
            System.out.println("Book available. Total cost for " + requiredCopies + " copies:-" + totalCost);
        } else {
            System.out.println("Required copies not in stock.");
        }
    }
}

public class BookShop {
    public static void main(String[] args) {
        Book[] books = {
            new Book("Java", "ABC", 500.0, "Publisher A", 5),
            new Book("OOPS", "DEF", 300.0, "Publisher B", 8),
            new Book("SQL", "GHI", 290.0, "Publisher C", 3)
        };

        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter book title: ");
        String inputTitle = scanner.nextLine();
        System.out.print("Enter book author: ");
        String inputAuthor = scanner.nextLine();

        boolean found = false;
        for (Book book : books) {
            book.checkAvailability(inputTitle, inputAuthor);
            found = true;
            break;
        }

        if (!found) {
            System.out.println("Book not found in inventory.");
            scanner.close();
            return;
        }

        System.out.print("Enter number of copies required: ");
        int requiredCopies = scanner.nextInt();
        scanner.nextLine();

        for (Book book : books) {
            book.processBookRequest(requiredCopies);
            break;
        }
    }
}

