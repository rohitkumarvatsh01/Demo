package Abstraction;
abstract class X{
	public abstract void display();
	
	public void show() {
		System.out.println("Calling the Showing Method");
	}
}

class Y extends X{
	public void display() {
		System.out.println("Calling the Display Method");
	}
}
public class Abstract {
	public static void main(String[] args) {
		Y obj=new Y();
		obj.display();
		obj.show();
	}
}
