package Abstraction;
abstract class Main{
	
	public abstract void main(); 
	
	public void display() {
		System.out.println("Main Method Calling");
	}
}

class Child extends Main{
	public void show() {
		System.out.println("Child Method Calling");
	}

	@Override
	public void main() {
		// TODO Auto-generated method stub
		
	}
}

public class AbstractClass {
	public static void main(String[] args) {
		Child obj=new Child();
		obj.show();
		obj.display();
	}
}
