package Abstraction;
abstract class Human{
	public abstract void human();
	
	public int age=10;
	public void age() {
		System.out.println("All Human Age is:- "+age);
	}
}

class Male extends Human{
	public void male() {
		age();
		System.out.println("All are Male");
	}

	@Override
	public void human() {
		// TODO Auto-generated method stub
		System.out.println("Override Method");
	}
}

class Female extends Human{
	public void female() {
		System.out.println("All are Female");
	}

	@Override
	public void human() {
		// TODO Auto-generated method stub
		System.out.println("Override Method");
	}
}

class AbstractClassMethod{
	public static void main(String[] args) {
		Male obj1=new Male();
		Female obj2=new Female();
		
		obj1.human();
		obj1.age();
		obj1.male();
		
		obj2.human();
		obj2.age();
		obj2.female();
	}
}