package Abstraction;
abstract class Animal{
	public abstract void animalSound();
	
	public void Sleep() {
		System.out.println("Zzz");
	}
}
class Dog extends Animal{
	public void sound() {
		System.out.println("Dog Sound is Booo Booo");
	}

	@Override
	public void animalSound() {
		// TODO Auto-generated method stub
		
	}
}

public class AbstractInterview {
	public static void main(String[] args) {
		Dog obj=new Dog();
		obj.Sleep();
		obj.sound();
	}
}
