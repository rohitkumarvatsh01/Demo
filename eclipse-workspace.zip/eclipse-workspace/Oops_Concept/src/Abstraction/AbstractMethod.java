package Abstraction;
//Abstract Class
abstract class Programming{
	//Abstract Method
	public abstract void developer();
	
	public int count=10;
}

class Html extends Programming{
	public void developer() {
		System.out.println(count);
		System.out.println("Rohit");
	}
}

class Java extends Programming{
	public void developer() {
		System.out.println("Rohit Kumar");
	}
}

public class AbstractMethod {
	public static void main(String[] args) {
		Html obj1=new Html();
		obj1.developer();
		Java obj2=new Java();
		obj2.developer();
	}
}
