package Abstraction;

interface A{
	public void display();
	public void show();
}

class B implements A{
	public void display() {
		System.out.println("Calling the Display Method");
	}
	public void show() {
		System.out.println("Calling the Show Method");
	}
}

public class Interface {
	public static void main(String[] args) {
		B obj=new B();
		obj.display();
		obj.show();
		
	}
}
