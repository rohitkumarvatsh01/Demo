package Abstraction;
interface Animals{
	public void animalSound();
	public void sleep();
}

class Dogs implements Animals{
	@Override
	public void animalSound() {
		System.out.println("Sound of Dog is Boo Boo");
	}
	@Override
	public void sleep() {
		System.out.println("Sleeping of Dog is Zzzz");
	}
}
public class InterfaceImplementation {
	public static void main(String[] args) {
		Dogs obj=new Dogs();
		obj.animalSound();
		obj.sleep();
	}
}
