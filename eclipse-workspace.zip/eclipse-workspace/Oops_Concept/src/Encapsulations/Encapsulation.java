package Encapsulations;

class Person{
	private String name;
	
	public void setValue(String name) {
		this.name=name;
	}
	
	public void getValue() {
		System.out.println("Name:- "+name);
	}
}

public class Encapsulation {
	public static void main(String[] args) {
		Person obj=new Person();
		obj.setValue("Rohit");
		obj.getValue();
	}
}
