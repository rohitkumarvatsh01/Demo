package Encapsulations;

class Student{
	private int rollNo;
	private String name;
	
	public int getRollNo() {
		return rollNo;
	}
	
	public void setRollNo(int rollNo) {
		this.rollNo = rollNo;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
}

public class EncapsulationImplementation {
	public static void main(String[] args) {
		Student obj=new Student();
		obj.setRollNo(233);
		System.out.println(obj.getRollNo());
		
		obj.setName("Rohit");
		System.out.println(obj.getName());
	}
}
