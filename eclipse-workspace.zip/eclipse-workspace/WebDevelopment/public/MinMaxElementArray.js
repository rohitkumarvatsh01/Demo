/**
 * 
 */

let arr=[1,2,3,4,5,6,7,8,9,10];
let min=arr[0];
let max=arr[0];

for(let i=0; i<arr.length; i++){
    if(arr[i]<min){
        min=arr[i];
    }else{
        max=arr[i];
    }
}

console.log("Minimum Element in Array:- ",min);
console.log("Maximum Element in Array:- ",max);