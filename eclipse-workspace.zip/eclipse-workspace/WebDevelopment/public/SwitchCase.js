/**
 * 
 */

 function getStatus(role){
	 let status;
	 
	 switch(role){
		 case 'admin':
		 status='Administrator';
		 break;
		 
		 case 'editor':
		 status='Editor';
		 break;
		 
		 case 'user':
		 status='User';
		 break;
		 
		 default:
			 status='Guest';
	 }
	 return status;
 }
 
 const userRole='editor';
 const userStatus=getStatus(userRole);