/**
 * 
 */

 const Student={
	 fullName:"Rohit",
	 age:23,
 };