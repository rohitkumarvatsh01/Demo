$(document).ready(function() {
  $("#getValues").click(function() {
    const selectedValue = $("#myDropdown").val();
    const selectedText = $("#myDropdown option:selected").text();

    $("#result").text("Selected Value: " + selectedValue + ", Selected Text: " + selectedText);
  });
});