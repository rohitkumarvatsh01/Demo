$(document).ready(function() {
  // hover() demonstration
  $("#username").hover(function() {
    $("#message").text("Hovering over username field");
  }, function() {
    $("#message").text("");
  });

  // focus() demonstration
  $("#password").focus(function() {
    $("#message").text("Password field is focused");
  });

  // blur() demonstration
  $("#password").blur(function() {
    $("#message").text("Password field lost focus");
  });
});