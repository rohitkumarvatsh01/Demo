$(document).ready(function() {
  $("#registrationForm").submit(function(event) {
    event.preventDefault();
    const isValid = validateForm();

    if (isValid) {
      alert("Registration successful!");
    }
  });

  function validateForm() {
    const requiredFields = ["firstName", "lastName", "gender", "password"];
    for (const field of requiredFields) {
      if ($("#" + field).val().trim() === "") {
        alert(`Please enter ${field}.`);
        return false;
      }
    }

    if ($("#password").val().length > 7) {
      alert("Password should not exceed 7 characters.");
      return false;
    }

    const dob = new Date($("#dob").val());
    const today = new Date();
    const age = today.getFullYear() - dob.getFullYear();
    if (age < 18) {
      alert("Minimum age for registration is 18 years.");
      return false;
    }

    return true;
  }
});